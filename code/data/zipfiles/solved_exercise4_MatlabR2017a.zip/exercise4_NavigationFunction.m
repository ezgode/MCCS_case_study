%%==========================================================================
%   TP :            Case study: Exercse 4
%   Contact:        ezequiel.gonzalezdebada@epfl.ch
%==========================================================================
close all;clear all;clc;

animate_flag = false;
simulate_flag = true;

simulation_time = 200;
sampling_time = 0.01;

ut = utilities;
sol4 = ut.load_solution_class(4);

%% load path of reference
chosen_path = sol4.select_reference_path;
simulate_flag = ut.solutionImplemented(chosen_path, 'select_reference_path', simulate_flag);
if ~isempty(chosen_path) 
    load(chosen_path);
else
    path_to_track = [];
end

%% Define the position of the obstacle path of reference
obstacle = sol4.getObstaclePosition;
simulate_flag = ut.solutionImplemented(obstacle, 'getObstaclePosition', simulate_flag);
%% Define the attractive potential fields 
attractive_field = sol4.getAttractiveField;
simulate_flag = ut.solutionImplemented(attractive_field, 'getAttractiveField', simulate_flag);
%% Define the repulsive potential fields 

% translate the coordinates of the obstacles
if simulate_flag
    dist_path_to_obs = sqrt(sum( (path_to_track.coordinates - repmat(obstacle,size(path_to_track.coordinates,1),1)).^2, 2));
    [min_dist, pos] = min(dist_path_to_obs);
    s_d_obstacle_coordinates = [path_to_track.s_coordinate(pos(1)), min_dist];

    %get the repulsive field
    repulsive_field = sol4.getRepulsiveField(s_d_obstacle_coordinates);
    simulate_flag = ut.solutionImplemented(repulsive_field, 'getRepulsiveField', simulate_flag);
    %plot the potential function
    if simulate_flag
        [ax] = ut.representPotentialFields(path_to_track, attractive_field, repulsive_field,'s_step',1,'d_step',1);
    end

    [~, potential_field, s, d, s_grid, d_grid] = ut.representPotentialFields(path_to_track, attractive_field, repulsive_field,'s_step',0.1,'d_step',0.1,'plot',false);

    %% Calculate the gradient 
    [fs,fd] = sol4.calculateGradient(potential_field, s, d);
    simulate_flag = ut.solutionImplemented(fs, 'calculateGradient', simulate_flag);

    %% get the result 
    [x0] = sol4.getInitialState();
    simulate_flag = ut.solutionImplemented(x0, 'getInitialState', simulate_flag);
    if ~isempty(x0)
        initial_pos_s_d = x0(1:2,1);
    else
        initial_pos_s_d  = [];
    end

    %% get the path and plot results
    if simulate_flag
        [path_s_d] = ut.obtainMinimumPotentialPath(initial_pos_s_d, s, d, fs, fd,'path_points',8000,'step_size',0.01);
        path = ut.SDCoordToXY( path_to_track, path_s_d(:,1), path_s_d(:,2));

        z = interp2(s_grid, d_grid, potential_field, path_s_d(:,1), path_s_d(:,2));
        plot(path(:,1),path(:,2),'LineWidth',2,'Parent',ax(5));
        plot3(path(:,1),path(:,2),z+100,'LineWidth',2,'Parent',ax(8),'Color',[1 0 0]);
        plot3(path_s_d(:,1),path_s_d(:,2),z+100,'LineWidth',2,'Parent',ax(4),'Color',[1 0 0]);
    end
end